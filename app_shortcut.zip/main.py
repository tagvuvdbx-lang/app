import webbrowser
from kivy.app import App
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.label import Label
from kivy.uix.button import Button
from kivy.uix.textinput import TextInput
from kivy.uix.screenmanager import ScreenManager, Screen
from kivy.uix.popup import Popup
from kivy.core.window import Window

# Set background color and window size orientation
Window.clearcolor = (0.1, 0.1, 0.12, 1)

class SubscriptionScreen(Screen):
    def __init__(self, **kwargs):
        super(SubscriptionScreen, self).__init__(**kwargs)
        layout = BoxLayout(orientation='vertical', padding=20, spacing=15)

        # Title
        title = Label(
            text="[b]REQUIRED STEPS[/b]\nJoin Channels to Unlock App",
            markup=True,
            font_size='22sp',
            halign='center',
            color=(1, 0.8, 0, 1)
        )
        layout.add_widget(title)

        # Telegram Channel Button
        btn_channel = Button(
            text="1. Join Telegram Channel",
            background_color=(0, 0.6, 1, 1),
            font_size='16sp',
            bold=True,
            size_hint_y=None,
            height=50
        )
        btn_channel.bind(on_release=lambda x: webbrowser.open("https://t.me/H4XDAKUVIPLAB"))
        layout.add_widget(btn_channel)

        # Telegram Group Button
        btn_group = Button(
            text="2. Join Telegram Group",
            background_color=(0, 0.6, 1, 1),
            font_size='16sp',
            bold=True,
            size_hint_y=None,
            height=50
        )
        btn_group.bind(on_release=lambda x: webbrowser.open("https://t.me/Gojo_EscrowService"))
        layout.add_widget(btn_group)

        # Verify Button
        btn_verify = Button(
            text="Verify & Continue",
            background_color=(0.2, 0.8, 0.2, 1),
            font_size='18sp',
            bold=True,
            size_hint_y=None,
            height=55
        )
        btn_verify.bind(on_release=self.go_to_payment)
        layout.add_widget(btn_verify)

        self.add_widget(layout)

    def go_to_payment(self, instance):
        self.manager.current = 'payment_screen'


class PaymentScreen(Screen):
    def __init__(self, **kwargs):
        super(PaymentScreen, self).__init__(**kwargs)
        layout = BoxLayout(orientation='vertical', padding=20, spacing=12)

        # Premium Title
        title = Label(
            text="[b]PREMIUM MEMBERSHIP[/b]\nFee: 300 INR",
            markup=True,
            font_size='22sp',
            halign='center',
            color=(1, 0.8, 0, 1)
        )
        layout.add_widget(title)

        # Payment Details
        info_label = Label(
            text="Pay via UPI to activate Creator Pro Access:\n\n[b]UPI ID:[/b] ratan143@fam\n[b]Amount:[/b] 300 INR",
            markup=True,
            font_size='16sp',
            halign='center'
        )
        layout.add_widget(info_label)

        # Dynamic Pay Button (Opens directly in UPI Apps)
        btn_pay_upi = Button(
            text="Pay 300 INR via UPI App",
            background_color=(0.9, 0.3, 0.2, 1),
            font_size='16sp',
            bold=True,
            size_hint_y=None,
            height=50
        )
        upi_link = "upi://pay?pa=ratan143@fam&pn=Arafat&am=300&cu=INR"
        btn_pay_upi.bind(on_release=lambda x: webbrowser.open(upi_link))
        layout.add_widget(btn_pay_upi)

        # Activation Code Input
        self.code_input = TextInput(
            hint_text="Enter Secret Activation Key",
            multiline=False,
            font_size='16sp',
            size_hint_y=None,
            height=45
        )
        layout.add_widget(self.code_input)

        # Unlock Button
        btn_unlock = Button(
            text="Unlock Creator Hub",
            background_color=(0.2, 0.8, 0.2, 1),
            font_size='18sp',
            bold=True,
            size_hint_y=None,
            height=50
        )
        btn_unlock.bind(on_release=self.check_activation_key)
        layout.add_widget(btn_unlock)

        self.add_widget(layout)

    def check_activation_key(self, instance):
        # Master Activation Secret Key
        secret_key = "VIP300"
        
        if self.code_input.text.strip() == secret_key:
            self.manager.current = 'main_app_screen'
        else:
            popup = Popup(
                title='Error',
                content=Label(text='Invalid Activation Key!\nPlease complete payment first.'),
                size_hint=(None, None), size=(300, 180)
            )
            popup.open()


class MainAppScreen(Screen):
    def __init__(self, **kwargs):
        super(MainAppScreen, self).__init__(**kwargs)
        layout = BoxLayout(orientation='vertical', padding=15, spacing=10)

        title_label = Label(
            text="[b]AI Creator Content Hub[/b]",
            markup=True,
            font_size='20sp',
            size_hint_y=None,
            height=30,
            color=(0.2, 1, 0.3, 1)
        )
        layout.add_widget(title_label)

        # Topic/Keyword Input for Creators
        self.topic_input = TextInput(
            hint_text="Enter topic (e.g. Tech, Fitness, Gaming...)",
            multiline=False,
            font_size='16sp',
            size_hint_y=None,
            height=45
        )
        layout.add_widget(self.topic_input)

        # Generate Button
        btn_generate = Button(
            text="Generate Viral Caption & Script",
            background_color=(0, 0.6, 1, 1),
            font_size='16sp',
            bold=True,
            size_hint_y=None,
            height=50
        )
        btn_generate.bind(on_release=self.generate_content)
        layout.add_widget(btn_generate)

        # Output Display Box
        self.output_label = Label(
            text="Your generated content will appear here...",
            font_size='14sp',
            halign='center',
            valign='middle'
        )
        self.output_label.bind(size=self.output_label.setter('text_size'))
        layout.add_widget(self.output_label)

        self.add_widget(layout)

    def generate_content(self, instance):
        topic = self.topic_input.text.strip()
        if not topic:
            self.output_label.text = "Please enter a valid topic first!"
            return
        
        # Simulated AI Generation for creators (Can be linked with Gemini API later)
        sample_output = (
            f"[Viral Script Idea for: {topic}]\n\n"
            f"1. Hook: Want to master {topic} in 24 hours?\n"
            f"2. Body: Here are the top 3 secret tips every creator should know...\n"
            f"3. CTA: Follow for more exclusive content!"
        )
        self.output_label.text = sample_output


class VIPAccessApp(App):
    def build(self):
        self.title = "VIP Tool & Access Hub"
        sm = ScreenManager()
        sm.add_widget(SubscriptionScreen(name='sub_screen'))
        sm.add_widget(PaymentScreen(name='payment_screen'))
        sm.add_widget(MainAppScreen(name='main_app_screen'))
        return sm

if __name__ == '__main__':
    VIPAccessApp().run()
    